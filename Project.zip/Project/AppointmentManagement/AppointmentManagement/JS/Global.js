﻿var ProviderEmail = "mirandaguo522@gmail.com";
var appointmentAddress = "http://devtechtest.previewourapp.com/api/Appointment/";
var userAddress = "http://devtechtest.previewourapp.com/api/user/";
