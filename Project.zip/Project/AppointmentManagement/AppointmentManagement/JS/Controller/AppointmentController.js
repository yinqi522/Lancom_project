﻿(function () {
    'use strict';
    var app = angular.module('AppointmentManagement');
    app.config(['$sceDelegateProvider', function ($sceDelegateProvider) {
        $sceDelegateProvider.resourceUrlWhitelist(['self', 'http://devtechtest.previewourapp.com/api/Appointment/**']);

    }]);

    app.controller('AppointmentController', function ($scope, $http, $location, $routeParams) {
        var currentAppointmentAddress = appointmentAddress + $routeParams.id;

        // Get the selected appointment's details
        $http({
                        method: 'GET',
                        url: currentAppointmentAddress,
                        params: {
                            'providerEmail': ProviderEmail
                        }
                    }).then(function successCallback(response) {
                        $scope.Appointment = response.data;
                    }, function errorCallback(response) {
                        $location.path("#/Error")
                    });
       
        $scope.NoteToAdd = "";
        $scope.isNotEditable = true;

        // Once the "edit" button is clicked, the "edit" button will be hided and all the input areas will be editable 
        // and a new text area for adding a note, an "Add Note" button and a "Submit" button will appear. 
        // Then once the "submit" button is clicked, the UI will get back to its original look.
        $scope.editClicked = function ()
        {
            $scope.isNotEditable = !$scope.isNotEditable;
        }

        // Update the information
        $scope.submitClicked = function()
        {
            currentAppointmentAddress = appointmentAddress + $scope.Appointment.Id;
            $scope.isNotEditable = !$scope.isNotEditable;

            $http({
                method: 'PUT',
                url: currentAppointmentAddress,
                params: {
                    'providerEmail': ProviderEmail
                },
                headers:
                    {
                        'Content-Type':'application/json'
                    },
                data: $scope.Appointment
            }).then(function successCallback(response) {
                alert("Success!")
                $scope.Appointment = response.data;
            }, function errorCallback(response) {
                alert("Error");
            });
        }
        
        // Add the new note to Notes List and clean the note input area
        $scope.addNoteClicked = function()
        {
            $scope.Appointment.Notes.push($scope.NoteToAdd);
            $scope.NoteToAdd = "";
        }
    });
})();