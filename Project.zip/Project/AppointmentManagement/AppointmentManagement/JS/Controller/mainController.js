﻿(function () {
    'use strict';
    var app = angular.module('AppointmentManagement', ['ngRoute']);
    app.controller('MainController', mainController);

    function mainController($scope)
    {
    }

    // Use ng-route to configure the URL and its response controller and template for single page app.
    app.config(['$routeProvider', function ($routeProvider) {
        $routeProvider
        .when('/', {
            templateUrl: '../../UI/Template/Home.html',
            controller: 'HomeController'
        })
        .when('/Appointment/:id', {
            templateUrl: '../../UI/Template/Appointment.html',
            controller: 'AppointmentController'
        })      
        .otherwise({ redirectTo: '/' });
    }]);
})();
