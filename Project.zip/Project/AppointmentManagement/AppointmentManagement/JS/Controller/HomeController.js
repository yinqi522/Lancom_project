﻿(function () {
    'use strict';
    var app = angular.module('AppointmentManagement');
    app.controller('HomeController', function ($scope,$http,$location) {        
        $scope.UserList = new Array();

        // Check whether the id belongs  to the user list
        $scope.checkUserId = function checkUserId(id, userList) {
            for (var i = 0; i < userList.length; i++) {
                if (userList[i].Id == id) {
                    return true;
                }
                
            }
            return false;
        }

        // Show the appointments related to the selected user
        $scope.userClick = function(index)
        {
            $scope.AppointmentList = $scope.OriginalAppointmentList;
            $scope.UserAppointList = new Array();
            var userId = $scope.UserList[index].Id;
            for(var i = 0;i< $scope.AppointmentList.length;i++)
            {
                var appointment = $scope.AppointmentList[i];
                var appointmentors = appointment.Party;
                for (var j = 0; j < appointmentors.length; j++)
                {
                    if (userId === appointmentors[j])
                    {
                        $scope.UserAppointList.push(appointment);
                    }
                }
            }
            $scope.AppointmentList = $scope.UserAppointList;
        }

        // Show the details of the selected appointment (double click)
        $scope.appointmentClick = function (index) {
            var appId = $scope.AppointmentList[index].Id;
            var appointmentAddress = "/Appointment/" + appId
            $location.path(appointmentAddress);
        }

        // Get all the appointments
        $http({
            method: 'GET',
            url: appointmentAddress,
            params: {
                'providerEmail': ProviderEmail
            }
        }).then(function successCallback(response) {
            $scope.OriginalAppointmentList = response.data;
            $scope.AppointmentList = $scope.OriginalAppointmentList;
        }, function errorCallback(response) {
            alert("error");
        });

        // Get all the users
        $http({                        
            method: 'GET',
            url: userAddress,
            params: {
                'providerEmail': ProviderEmail
            }
        }).then(function successCallback(response) {
            $scope.UserList = response.data;
        }, function errorCallback(response) {
            alert("error");
        });
    });  
}




)();


